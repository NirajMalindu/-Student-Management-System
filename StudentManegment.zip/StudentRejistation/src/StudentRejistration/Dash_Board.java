/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package StudentRejistration;

/**
 *
 * @author Shaminda
 */


import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class Dash_Board extends javax.swing.JFrame {

    private static void add(jPanelStudentDetails1 pane1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    
    
    //database eke tika
       String URL = "jdbc:mysql://localhost:3306/management_system";
       String USER = "root";
       String PASSWORD = "shaminda2002#";
    
       
       
       
       
       
    public Dash_Board() {
        initComponents();
         
        
        //Dash Board eke
         setSize(2000,850);
         jTabbedPane1.setVisible(false);
         setLocationRelativeTo(null);
         
         
         
         
         //Teacher registration eke Teacher_id eka enable kara
             TxtTRID.setEnabled(false);
         //Student registration eke Student_id eka enable kara
            TxtRStID.setEnabled(false);
              
             
    }

    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel11 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabelPic = new javax.swing.JLabel();
        LblOlympus2 = new javax.swing.JLabel();
        LblOlympus3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        BtnLogOut = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        BtnRejistration = new javax.swing.JButton();
        BtnAttendence = new javax.swing.JButton();
        BtnPayment = new javax.swing.JButton();
        BtnAlldetails = new javax.swing.JButton();
        BtnReport = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        Btnregistration = new javax.swing.JButton();
        Btnalldetails = new javax.swing.JButton();
        BtnTimeShedule = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanelRegistation = new javax.swing.JPanel();
        LblName = new javax.swing.JLabel();
        TxtRName = new javax.swing.JTextField();
        LblBirth = new javax.swing.JLabel();
        LblGender = new javax.swing.JLabel();
        LblAddress = new javax.swing.JLabel();
        TxtRAddress = new javax.swing.JTextField();
        LblNumber = new javax.swing.JLabel();
        TxtRNumber = new javax.swing.JTextField();
        LblSubject = new javax.swing.JLabel();
        JRComboBoxGrade = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        LblPname = new javax.swing.JLabel();
        TxtRPname = new javax.swing.JTextField();
        Lblnumber = new javax.swing.JLabel();
        TxtRPnumber = new javax.swing.JTextField();
        LblRejistation = new javax.swing.JLabel();
        LblStID = new javax.swing.JLabel();
        TxtRStID = new javax.swing.JTextField();
        BtnRSubmit = new javax.swing.JButton();
        BtnRReset = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jComboBoxGender = new javax.swing.JComboBox<>();
        SRSbject = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        jAttendence = new javax.swing.JPanel();
        JAGrade = new javax.swing.JComboBox<>();
        JASubject = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        JATable = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        JVAGrade = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        JVASubject = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        JVATable = new javax.swing.JTable();
        BtnASubmit = new javax.swing.JButton();
        BtnAReset = new javax.swing.JButton();
        jPayment = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        TxtPStID = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        JVPTable = new javax.swing.JTable();
        JVPGrade1 = new javax.swing.JComboBox<>();
        JPVPSubject1 = new javax.swing.JComboBox<>();
        jPVPSearch = new javax.swing.JButton();
        btnVPRefresh = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        btnPSTudentIDSearch = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        TxtPName = new javax.swing.JTextField();
        TxtPID = new javax.swing.JTextField();
        JPStatus = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        JPSubject = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        TxtPAmount = new javax.swing.JTextField();
        btnPSubmit = new javax.swing.JButton();
        btnPReset = new javax.swing.JButton();
        JPGrade = new javax.swing.JTextField();
        jPanelStudentDetails = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        JSDGrade = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        JSDTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        BtnSDSearch = new javax.swing.JButton();
        BtnSDRefresh = new javax.swing.JButton();
        BtnSDDelete = new javax.swing.JButton();
        TxtSDStudentID = new javax.swing.JTextField();
        BtnSDEdit1 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jReport = new javax.swing.JPanel();
        jTRegistration = new javax.swing.JPanel();
        LblTName = new javax.swing.JLabel();
        LblTAddress = new javax.swing.JLabel();
        LblTNumber = new javax.swing.JLabel();
        LblTSubject = new javax.swing.JLabel();
        LblTID = new javax.swing.JLabel();
        TxtTRname = new javax.swing.JTextField();
        TxtTRaddress = new javax.swing.JTextField();
        TxtTRnumber = new javax.swing.JTextField();
        JTRsubject = new javax.swing.JComboBox<>();
        TxtTRID = new javax.swing.JTextField();
        BtnTRSubmit = new javax.swing.JButton();
        BtnTRReset = new javax.swing.JButton();
        LblTID1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        JATGrade1 = new javax.swing.JComboBox<>();
        LblSubject3 = new javax.swing.JLabel();
        LblStID4 = new javax.swing.JLabel();
        LblStID5 = new javax.swing.JLabel();
        TxtATTime1 = new javax.swing.JTextField();
        JATD2 = new javax.swing.JComboBox<>();
        jTDetails = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        TDetailsTable = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        BtnTDRefresh = new javax.swing.JButton();
        BtnTDDelete = new javax.swing.JButton();
        TxtTDTeacherId = new javax.swing.JTextField();
        BtnTSearch = new javax.swing.JButton();
        BtnTDExit1 = new javax.swing.JButton();
        jShedule = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        JTSTable1 = new javax.swing.JTable();
        BtnTSSearch = new javax.swing.JButton();
        BtnTSRefresh = new javax.swing.JButton();
        TxtTSTeacherID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(242, 246, 212));

        jPanel11.setBackground(new java.awt.Color(243, 227, 215));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(244, 229, 218));
        jPanel2.setPreferredSize(new java.awt.Dimension(1001, 90));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelPic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentRejistration/777_170x85.jpg"))); // NOI18N
        jLabelPic.setText("logo");
        jLabelPic.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(jLabelPic, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 157, 80));

        LblOlympus2.setFont(new java.awt.Font("Bookman Old Style", 1, 36)); // NOI18N
        LblOlympus2.setText("OLYMPUS");
        jPanel2.add(LblOlympus2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 200, -1));

        LblOlympus3.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        LblOlympus3.setText("Institute Of Education");
        jPanel2.add(LblOlympus3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 50, 310, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Employee Dash Board");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 20, -1, -1));

        BtnLogOut.setBackground(new java.awt.Color(247, 241, 236));
        BtnLogOut.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnLogOut.setText("Log Out");
        BtnLogOut.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLogOutActionPerformed(evt);
            }
        });
        jPanel2.add(BtnLogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 50, 90, 30));

        jPanel11.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1520, 100));

        jPanel1.setBackground(new java.awt.Color(243, 227, 215));
        jPanel1.setPreferredSize(new java.awt.Dimension(190, 537));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BtnRejistration.setBackground(new java.awt.Color(247, 241, 236));
        BtnRejistration.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnRejistration.setText("Registration");
        BtnRejistration.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnRejistration.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnRejistration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRejistrationActionPerformed(evt);
            }
        });
        jPanel1.add(BtnRejistration, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 140, -1));

        BtnAttendence.setBackground(new java.awt.Color(247, 241, 236));
        BtnAttendence.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnAttendence.setText("Attendence");
        BtnAttendence.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnAttendence.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnAttendence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAttendenceActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAttendence, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 140, -1));

        BtnPayment.setBackground(new java.awt.Color(247, 241, 236));
        BtnPayment.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnPayment.setText("Payment");
        BtnPayment.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnPayment.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPaymentActionPerformed(evt);
            }
        });
        jPanel1.add(BtnPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 140, -1));

        BtnAlldetails.setBackground(new java.awt.Color(247, 241, 236));
        BtnAlldetails.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnAlldetails.setText("Stu. Details");
        BtnAlldetails.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnAlldetails.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnAlldetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAlldetailsActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAlldetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 140, -1));

        BtnReport.setBackground(new java.awt.Color(247, 241, 236));
        BtnReport.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnReport.setText("Report");
        BtnReport.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnReport.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnReportActionPerformed(evt);
            }
        });
        jPanel1.add(BtnReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 140, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Students :");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 70, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Teachers :");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 75, 24));

        Btnregistration.setBackground(new java.awt.Color(247, 241, 236));
        Btnregistration.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        Btnregistration.setText("Registration");
        Btnregistration.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        Btnregistration.setPreferredSize(new java.awt.Dimension(120, 30));
        Btnregistration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnregistrationActionPerformed(evt);
            }
        });
        jPanel1.add(Btnregistration, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 140, -1));

        Btnalldetails.setBackground(new java.awt.Color(247, 241, 236));
        Btnalldetails.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        Btnalldetails.setText("TE. Details");
        Btnalldetails.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        Btnalldetails.setPreferredSize(new java.awt.Dimension(120, 30));
        Btnalldetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnalldetailsActionPerformed(evt);
            }
        });
        jPanel1.add(Btnalldetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 140, -1));

        BtnTimeShedule.setBackground(new java.awt.Color(247, 241, 236));
        BtnTimeShedule.setFont(new java.awt.Font("Cambria", 1, 12)); // NOI18N
        BtnTimeShedule.setText("Time Shedule");
        BtnTimeShedule.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(247, 241, 236), new java.awt.Color(243, 227, 215)));
        BtnTimeShedule.setPreferredSize(new java.awt.Dimension(120, 30));
        BtnTimeShedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTimeSheduleActionPerformed(evt);
            }
        });
        jPanel1.add(BtnTimeShedule, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 140, -1));

        jPanel11.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jPanelRegistation.setBackground(new java.awt.Color(249, 244, 240));
        jPanelRegistation.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LblName.setText("Full  Name :");
        jPanelRegistation.add(LblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));
        jPanelRegistation.add(TxtRName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 230, -1));

        LblBirth.setText("Date Of Birth :");
        jPanelRegistation.add(LblBirth, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 90, -1));

        LblGender.setText("Gender :");
        jPanelRegistation.add(LblGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, -1, -1));

        LblAddress.setText("Address :");
        jPanelRegistation.add(LblAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, 60, -1));
        jPanelRegistation.add(TxtRAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 230, -1));

        LblNumber.setText("Phone Number :");
        jPanelRegistation.add(LblNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, 90, -1));
        jPanelRegistation.add(TxtRNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 230, -1));

        LblSubject.setText("Grade:");
        jPanelRegistation.add(LblSubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, 80, -1));

        JRComboBoxGrade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6", "7", "8", "9", "10", "11" }));
        jPanelRegistation.add(JRComboBoxGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 320, 230, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Parent/Gaurdin :");
        jPanelRegistation.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, -1, -1));

        LblPname.setText("Name :");
        jPanelRegistation.add(LblPname, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 530, 40, -1));
        jPanelRegistation.add(TxtRPname, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 230, -1));

        Lblnumber.setText("Phone Number :");
        jPanelRegistation.add(Lblnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 580, 90, -1));
        jPanelRegistation.add(TxtRPnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 570, 230, -1));

        LblRejistation.setText("Date Of Rejistation :");
        jPanelRegistation.add(LblRejistation, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 400, 110, -1));

        LblStID.setText("Student ID :");
        jPanelRegistation.add(LblStID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 440, -1, -1));
        jPanelRegistation.add(TxtRStID, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 440, 230, -1));

        BtnRSubmit.setBackground(new java.awt.Color(232, 228, 228));
        BtnRSubmit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnRSubmit.setText("Submit");
        BtnRSubmit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnRSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRSubmitActionPerformed(evt);
            }
        });
        jPanelRegistation.add(BtnRSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 630, 90, 30));

        BtnRReset.setBackground(new java.awt.Color(232, 228, 228));
        BtnRReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnRReset.setText("Reset");
        BtnRReset.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnRReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRResetActionPerformed(evt);
            }
        });
        jPanelRegistation.add(BtnRReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 630, 100, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Student :");
        jPanelRegistation.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        jComboBoxGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "male", "female" }));
        jPanelRegistation.add(jComboBoxGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 230, -1));

        SRSbject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil " }));
        jPanelRegistation.add(SRSbject, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 360, 230, -1));

        jLabel20.setText("Subject :");
        jPanelRegistation.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, -1, -1));

        jTabbedPane1.addTab("Registration", jPanelRegistation);

        jAttendence.setBackground(new java.awt.Color(247, 241, 236));
        jAttendence.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JAGrade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", " " }));
        jAttendence.add(JAGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        JASubject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil ", " ", " ", " " }));
        jAttendence.add(JASubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, -1, -1));

        JATable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Student ID", "Student Name", "Status"
            }
        ));
        jScrollPane1.setViewportView(JATable);

        jAttendence.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 450, 370));

        jPanel12.setBackground(new java.awt.Color(219, 218, 218));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JVAGrade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11" }));
        jPanel12.add(JVAGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("View Attendence:");
        jPanel12.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 120, -1));

        JVASubject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil " }));
        jPanel12.add(JVASubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, -1, -1));

        JVATable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Student ID", "Student Name", "Status"
            }
        ));
        jScrollPane3.setViewportView(JVATable);

        jPanel12.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 750, -1));

        jAttendence.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, -10, 790, 740));

        BtnASubmit.setBackground(new java.awt.Color(232, 228, 228));
        BtnASubmit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnASubmit.setText("Submit");
        BtnASubmit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jAttendence.add(BtnASubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 560, 90, 30));

        BtnAReset.setBackground(new java.awt.Color(232, 228, 228));
        BtnAReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnAReset.setText("Reset");
        BtnAReset.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jAttendence.add(BtnAReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 560, 100, 30));

        jTabbedPane1.addTab("Attendence", jAttendence);

        jPayment.setBackground(new java.awt.Color(247, 241, 236));
        jPayment.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setText("Student ID:");
        jPayment.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        TxtPStID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(TxtPStID, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 160, -1));

        jPanel13.setBackground(new java.awt.Color(219, 218, 218));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("View Payment:");
        jPanel13.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 120, -1));

        JVPTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Student ID", "Student Name", "Grade", "Subject", "Amount", "Status", "Paid Month"
            }
        ));
        jScrollPane4.setViewportView(JVPTable);
        if (JVPTable.getColumnModel().getColumnCount() > 0) {
            JVPTable.getColumnModel().getColumn(0).setPreferredWidth(20);
            JVPTable.getColumnModel().getColumn(1).setPreferredWidth(80);
            JVPTable.getColumnModel().getColumn(2).setPreferredWidth(20);
            JVPTable.getColumnModel().getColumn(5).setPreferredWidth(20);
        }

        jPanel13.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 930, -1));

        JVPGrade1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6", "7", "8", "9", "10", "11" }));
        JVPGrade1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.add(JVPGrade1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, 90, 20));

        JPVPSubject1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil " }));
        JPVPSubject1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.add(JPVPSubject1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 100, 20));

        jPVPSearch.setText("Search");
        jPVPSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPVPSearchActionPerformed(evt);
            }
        });
        jPanel13.add(jPVPSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 90, -1, 20));

        btnVPRefresh.setText("Refresh");
        btnVPRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVPRefreshActionPerformed(evt);
            }
        });
        jPanel13.add(btnVPRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, -1, -1));

        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 110, 20));

        jLabel12.setText("Student Id:");
        jPanel13.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        jPayment.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 950, 730));

        jLabel16.setText("Student ID:");
        jPayment.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, -1));

        jLabel18.setText("Student Name:");
        jPayment.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        jLabel19.setText("Which Month:");
        jPayment.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, -1, -1));

        btnPSTudentIDSearch.setText("Search");
        btnPSTudentIDSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPSTudentIDSearchActionPerformed(evt);
            }
        });
        jPayment.add(btnPSTudentIDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, -1, -1));

        jLabel21.setText("Subject:");
        jPayment.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 50, -1));

        TxtPName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(TxtPName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 160, -1));

        TxtPID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(TxtPID, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 160, -1));

        JPStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Paid", "Not Paid" }));
        JPStatus.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(JPStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 360, 70, -1));

        jLabel22.setText("Status:");
        jPayment.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, -1, -1));

        JPSubject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil " }));
        JPSubject.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(JPSubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 160, -1));

        jLabel23.setText("Grade:");
        jPayment.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 50, -1));

        jLabel11.setText("Amount:");
        jPayment.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, -1, -1));

        TxtPAmount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(TxtPAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 320, 160, -1));

        btnPSubmit.setText("Submit");
        btnPSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPSubmitActionPerformed(evt);
            }
        });
        jPayment.add(btnPSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 490, -1, -1));

        btnPReset.setText("Reset");
        btnPReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPResetActionPerformed(evt);
            }
        });
        jPayment.add(btnPReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 490, -1, -1));

        JPGrade.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPayment.add(JPGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 160, -1));

        jTabbedPane1.addTab("Payment ", jPayment);

        jPanelStudentDetails.setBackground(new java.awt.Color(247, 241, 236));
        jPanelStudentDetails.setForeground(new java.awt.Color(255, 255, 255));
        jPanelStudentDetails.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel4.setText("Student Details");
        jPanelStudentDetails.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Subject:");
        jPanelStudentDetails.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, 50, -1));

        JSDGrade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6", "7", "8", "9", "10", "11", " " }));
        JSDGrade.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                JSDGradeComponentHidden(evt);
            }
        });
        jPanelStudentDetails.add(JSDGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, 130, -1));

        JSDTable.setAutoCreateRowSorter(true);
        JSDTable.setBackground(new java.awt.Color(235, 235, 235));
        JSDTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Student Name", "Address", "Student Tel", "Gender", "D.O.B", "D.O.R", "Grade", "Subject", "Parent Name", "Parent Tel No"
            }
        ));
        jScrollPane2.setViewportView(JSDTable);

        jPanelStudentDetails.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 1250, 500));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Student ID :");
        jPanelStudentDetails.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        BtnSDSearch.setBackground(new java.awt.Color(232, 228, 228));
        BtnSDSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnSDSearch.setText("Search");
        BtnSDSearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnSDSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSDSearchActionPerformed(evt);
            }
        });
        jPanelStudentDetails.add(BtnSDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 90, 90, 30));

        BtnSDRefresh.setBackground(new java.awt.Color(232, 228, 228));
        BtnSDRefresh.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnSDRefresh.setText("Refresh");
        BtnSDRefresh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnSDRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSDRefreshActionPerformed(evt);
            }
        });
        jPanelStudentDetails.add(BtnSDRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 90, 90, 30));

        BtnSDDelete.setBackground(new java.awt.Color(232, 228, 228));
        BtnSDDelete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnSDDelete.setText("Delete");
        BtnSDDelete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnSDDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSDDeleteActionPerformed(evt);
            }
        });
        jPanelStudentDetails.add(BtnSDDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 90, 90, 30));
        jPanelStudentDetails.add(TxtSDStudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 180, -1));

        BtnSDEdit1.setBackground(new java.awt.Color(232, 228, 228));
        BtnSDEdit1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnSDEdit1.setText("Edit");
        BtnSDEdit1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnSDEdit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSDEdit1ActionPerformed(evt);
            }
        });
        jPanelStudentDetails.add(BtnSDEdit1, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 90, 90, 30));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setText("Grade:");
        jPanelStudentDetails.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, 50, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths   ", "Science ", "English  ", "Commerce ", "History  ", "Geogrophy ", "Art ", "Tamil " }));
        jPanelStudentDetails.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 100, 100, -1));

        jTabbedPane1.addTab("S. Details", jPanelStudentDetails);

        jReport.setBackground(new java.awt.Color(247, 241, 236));

        javax.swing.GroupLayout jReportLayout = new javax.swing.GroupLayout(jReport);
        jReport.setLayout(jReportLayout);
        jReportLayout.setHorizontalGroup(
            jReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1320, Short.MAX_VALUE)
        );
        jReportLayout.setVerticalGroup(
            jReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 845, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("S. Report", jReport);

        jTRegistration.setBackground(new java.awt.Color(247, 241, 236));
        jTRegistration.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LblTName.setText("Full Name:");
        jTRegistration.add(LblTName, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, -1));

        LblTAddress.setText("Address:");
        jTRegistration.add(LblTAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 60, -1));

        LblTNumber.setText("Phone Number:");
        jTRegistration.add(LblTNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 90, -1));

        LblTSubject.setText("Subject :");
        jTRegistration.add(LblTSubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 80, -1));

        LblTID.setText("Teacher ID:");
        jTRegistration.add(LblTID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 260, -1, -1));
        jTRegistration.add(TxtTRname, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 230, -1));
        jTRegistration.add(TxtTRaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 230, -1));
        jTRegistration.add(TxtTRnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 230, -1));

        JTRsubject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sinhala ", "Maths ", "Science ", "English ", "Commerce ", "History ", "Geogrophy", "Art", "Tamil ", " " }));
        jTRegistration.add(JTRsubject, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 230, -1));
        jTRegistration.add(TxtTRID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 230, -1));

        BtnTRSubmit.setBackground(new java.awt.Color(232, 228, 228));
        BtnTRSubmit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTRSubmit.setText("Submit");
        BtnTRSubmit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTRSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTRSubmitActionPerformed(evt);
            }
        });
        jTRegistration.add(BtnTRSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 550, 90, 30));

        BtnTRReset.setBackground(new java.awt.Color(232, 228, 228));
        BtnTRReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTRReset.setText("Reset");
        BtnTRReset.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTRReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTRResetActionPerformed(evt);
            }
        });
        jTRegistration.add(BtnTRReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 550, 100, 30));

        LblTID1.setText("Date of Registration");
        jTRegistration.add(LblTID1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Add Time for the Time Shedule");
        jTRegistration.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, -1));

        JATGrade1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6", "7", "8", "9", "10", "11" }));
        jTRegistration.add(JATGrade1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 390, 230, -1));

        LblSubject3.setText("Grade:");
        jTRegistration.add(LblSubject3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 80, -1));

        LblStID4.setText("Time");
        jTRegistration.add(LblStID4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 430, -1, -1));

        LblStID5.setText("Date");
        jTRegistration.add(LblStID5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, -1, -1));
        jTRegistration.add(TxtATTime1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 430, 230, -1));

        JATD2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" }));
        jTRegistration.add(JATD2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 480, 230, -1));

        jTabbedPane1.addTab("T. Registration", jTRegistration);

        jTDetails.setBackground(new java.awt.Color(247, 241, 236));
        jTDetails.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TDetailsTable.setAutoCreateRowSorter(true);
        TDetailsTable.setBackground(new java.awt.Color(235, 235, 235));
        TDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "TeacherID", "Teacher Name", "Address", "Tel No", "D.O.R", "Subject"
            }
        ));
        jScrollPane6.setViewportView(TDetailsTable);

        jTDetails.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 1210, 500));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setText("Teacher ID :");
        jTDetails.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        BtnTDRefresh.setBackground(new java.awt.Color(232, 228, 228));
        BtnTDRefresh.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTDRefresh.setText("Refresh");
        BtnTDRefresh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTDRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTDRefreshActionPerformed(evt);
            }
        });
        jTDetails.add(BtnTDRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 40, 90, 30));

        BtnTDDelete.setBackground(new java.awt.Color(232, 228, 228));
        BtnTDDelete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTDDelete.setText("Delete");
        BtnTDDelete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTDDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTDDeleteActionPerformed(evt);
            }
        });
        jTDetails.add(BtnTDDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 40, 90, 30));
        jTDetails.add(TxtTDTeacherId, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 210, -1));

        BtnTSearch.setBackground(new java.awt.Color(231, 227, 227));
        BtnTSearch.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        BtnTSearch.setText("Search");
        BtnTSearch.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        BtnTSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTSearchActionPerformed(evt);
            }
        });
        jTDetails.add(BtnTSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 50, 90, 20));

        BtnTDExit1.setBackground(new java.awt.Color(232, 228, 228));
        BtnTDExit1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTDExit1.setText("Edit");
        BtnTDExit1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTDExit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTDExit1ActionPerformed(evt);
            }
        });
        jTDetails.add(BtnTDExit1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 40, 90, 30));

        jTabbedPane1.addTab("T.Details", jTDetails);

        jShedule.setBackground(new java.awt.Color(247, 241, 236));
        jShedule.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JTSTable1.setAutoCreateRowSorter(true);
        JTSTable1.setBackground(new java.awt.Color(235, 235, 235));
        JTSTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "TeacherID", "Teacher Name", "Subject", "Date", "Time"
            }
        ));
        jScrollPane7.setViewportView(JTSTable1);

        jShedule.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 1210, 540));

        BtnTSSearch.setBackground(new java.awt.Color(232, 228, 228));
        BtnTSSearch.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTSSearch.setText("Search");
        BtnTSSearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTSSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTSSearchActionPerformed(evt);
            }
        });
        jShedule.add(BtnTSSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, 90, 30));

        BtnTSRefresh.setBackground(new java.awt.Color(232, 228, 228));
        BtnTSRefresh.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnTSRefresh.setText("Refresh");
        BtnTSRefresh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnTSRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTSRefreshActionPerformed(evt);
            }
        });
        jShedule.add(BtnTSRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 40, 90, 30));
        jShedule.add(TxtTSTeacherID, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, 180, -1));

        jLabel5.setText("Teacher ID:");
        jShedule.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 50, -1, -1));

        jTabbedPane1.addTab("Time Shedule", jShedule);

        jPanel11.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 1320, 880));

        getContentPane().add(jPanel11, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

   
    
    
    
    
    private void BtnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLogOutActionPerformed
        Login m1=new Login();
        m1.setVisible(true);

        setVisible(false);
    }//GEN-LAST:event_BtnLogOutActionPerformed

    
    
    
    
    
    
    // Panel tika call karapu eka
    private void BtnAttendenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAttendenceActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_BtnAttendenceActionPerformed

    private void BtnPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPaymentActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_BtnPaymentActionPerformed

    private void BtnAlldetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAlldetailsActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_BtnAlldetailsActionPerformed

    private void BtnReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnReportActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_BtnReportActionPerformed

    private void BtnregistrationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnregistrationActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(5); 
    }//GEN-LAST:event_BtnregistrationActionPerformed

    private void BtnalldetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnalldetailsActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_BtnalldetailsActionPerformed

    private void BtnTimeSheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTimeSheduleActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(7);
    }//GEN-LAST:event_BtnTimeSheduleActionPerformed
 
    private void BtnRejistrationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRejistrationActionPerformed
        jTabbedPane1.setVisible(true);
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_BtnRejistrationActionPerformed

    
    
    
    
    
    
    
    // Student Registration eke Reset Button eka
    private void BtnRResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRResetActionPerformed
        TxtRName.setText(null);
        JRDate.setDate(null);
        TxtRAddress.setText(null);
        TxtRNumber.setText(null);
        JRDateChooserRe.setCalendar(null);
        TxtRStID.setText(null);
        TxtRPname.setText(null);
        TxtRPnumber.setText(null);
        
        if(JRComboBoxGrade.getItemCount() > 0){
            JRComboBoxGrade.setSelectedIndex(0);
        } 
        if(jComboBoxGender.getItemCount() > 0){
            jComboBoxGender.setSelectedIndex(0);
        }
    }//GEN-LAST:event_BtnRResetActionPerformed

    
    
    // Student registration eke Submit Button eka 
    private void BtnRSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRSubmitActionPerformed

           
        
            String parentName = TxtRPname.getText();
            String parentPhone = TxtRPnumber.getText();
            String fullName = TxtRName.getText();
            String address = TxtRAddress.getText();
            String sphone = TxtRNumber.getText();
            String gender = (String) jComboBoxGender.getSelectedItem();
            String grade = (String) JRComboBoxGrade.getSelectedItem();
            String subject = (String) SRSbject.getSelectedItem();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dob = dateFormat.format(JRDate.getDate());
            String dor = dateFormat.format(JRDateChooserRe.getDate());

            boolean isValid = true;
            String errorMessage = "";

            if (parentName.isEmpty() || parentPhone.isEmpty() || fullName.isEmpty() || address.isEmpty() || sphone.isEmpty() || gender.isEmpty() 
                    || grade.isEmpty() || dob.isEmpty() || dor.isEmpty()) {
                isValid = false;
                errorMessage = "Please fill in all fields.";
            } else if (!parentName.matches("[a-zA-Z\\s]+")) {
                isValid = false;
                errorMessage = "Invalid parent name. Only alphabets and spaces are allowed.";
            } else if (!parentPhone.matches("\\d{10}")) {
                isValid = false;
                errorMessage = "Invalid parent phone number. Must be 10 digits.";
            } else if (!fullName.matches("[a-zA-Z\\s]+")) {
                isValid = false;
                errorMessage = "Invalid student name. Only alphabets and spaces are allowed.";
            } else if (!sphone.matches("\\d{10}")) {
                isValid = false;
                errorMessage = "Invalid student phone number. Must be 10 digits.";
            }

            if (!isValid) {
                JOptionPane.showMessageDialog(this, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    int newParentId;
                    try (PreparedStatement lastParentIdStatement = con.prepareStatement("SELECT COALESCE(MAX(Parent_Id), 0) + 1 AS NewParentId FROM parent")) {
                        ResultSet resultSet = lastParentIdStatement.executeQuery();
                        resultSet.next();
                        newParentId = resultSet.getInt("NewParentId");
                    }

                    try (PreparedStatement parentStatement = con.prepareStatement("INSERT INTO parent (Parent_Id, Parent_Name, PTelephone_Num) VALUES (?, ?, ?)")) {
                        parentStatement.setInt(1, newParentId);
                        parentStatement.setString(2, parentName);
                        parentStatement.setString(3, parentPhone);
                        parentStatement.executeUpdate();
                    }

                    int newStudentId;
                    try (PreparedStatement lastStudentIdStatement = con.prepareStatement("SELECT COALESCE(MAX(Student_Id), 0) + 1 AS NewStudentId FROM student")) {
                        ResultSet resultSet = lastStudentIdStatement.executeQuery();
                        resultSet.next();
                        newStudentId = resultSet.getInt("NewStudentId");
                    }

                    try (PreparedStatement studentStatement = con.prepareStatement("INSERT INTO student (Student_Id, Parent_Id, FUll_Name, Address, Gender, "
                            + "Date_Of_Birth, Date_Of_Reg, Grade, Telephone_num) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                        studentStatement.setInt(1, newStudentId);
                        studentStatement.setInt(2, newParentId);
                        studentStatement.setString(3, fullName);
                        studentStatement.setString(4, address);
                        studentStatement.setString(5, gender);
                        studentStatement.setString(6, dob);
                        studentStatement.setString(7, dor);
                        studentStatement.setString(8, grade);
                        studentStatement.setString(9, sphone);
                        studentStatement.executeUpdate();
                    }

                    int newSubjectId;
                    try (PreparedStatement lastSubjectIdStatement = con.prepareStatement("SELECT COALESCE(MAX(Subject_Id), 0) + 1 AS NewSubjectId FROM subject")) {
                        ResultSet resultSet = lastSubjectIdStatement.executeQuery();
                        resultSet.next();
                        newSubjectId = resultSet.getInt("NewSubjectId");
                    }

                    try (PreparedStatement subjectStatement = con.prepareStatement("INSERT INTO subject (Subject_Id, SubjectName) VALUES (?, ?)")) {
                        subjectStatement.setInt(1, newSubjectId);
                        subjectStatement.setString(2, subject);
                        subjectStatement.executeUpdate();
                    }

                    try (PreparedStatement studentSubjectStatement = con.prepareStatement("INSERT INTO student_subject (Student_Id, Subject_Id) VALUES (?, ?)")) {
                        studentSubjectStatement.setInt(1, newStudentId);
                        studentSubjectStatement.setInt(2, newSubjectId);
                        studentSubjectStatement.executeUpdate();
                    }

                    JOptionPane.showMessageDialog(this, "Registered Successfully! Student ID = " + newStudentId);
                    // Clear input fields
                    TxtRPname.setText("");
                    TxtRPnumber.setText("");
                    TxtRName.setText("");
                    TxtRAddress.setText("");
                    TxtRNumber.setText("");
                    JRDate.setCalendar(null);
                    JRDateChooserRe.setCalendar(null);
                    if (JRComboBoxGrade.getItemCount() > 0) {
                        JRComboBoxGrade.setSelectedIndex(0);
                    }
                    if (jComboBoxGender.getItemCount() > 0) {
                        jComboBoxGender.setSelectedIndex(0);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(this, "Error occurred while registering student.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

    }//GEN-LAST:event_BtnRSubmitActionPerformed

    
    
    
    
     // Teacher registration eke submit button eka 
    private void BtnTRSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTRSubmitActionPerformed
        
            String teacherName = TxtTRname.getText();
            String TAddress = TxtTRaddress.getText();
            String TPhone = TxtTRnumber.getText();
            String time = TxtATTime1.getText();
            String subject = (String) JTRsubject.getSelectedItem();
            String grade = (String) JATGrade1.getSelectedItem();
            String date = (String) JATD2.getSelectedItem();
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String TDor = dateFormat.format(JATDor.getDate());

            
            // Validation tika damma(histhan thibboth erroe massage eka enawa)
            if (teacherName.isEmpty() || TAddress.isEmpty() || TPhone.isEmpty() || subject.isEmpty() || grade.isEmpty() || time.isEmpty() || TDor.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            } 
                        else {
                         boolean isValid = true;
                              
                         if (teacherName.matches("[0-9]+")) {
                             isValid = false;
                             TxtTRname.setForeground(java.awt.Color.RED);
                         } else {
                             TxtTRname.setForeground(java.awt.Color.BLACK);
                         }

                         
                         if (TPhone.matches("[a-z A-Z]+") || TPhone.length() > 10) {
                             isValid = false;
                             TxtTRnumber.setForeground(java.awt.Color.RED);
                         } else {
                             TxtTRnumber.setForeground(java.awt.Color.BLACK);
                         }
                         

                         if (time.matches("[a-zA-Z]+")) {
                             isValid = false;
                             TxtATTime1.setForeground(java.awt.Color.RED);
                         } else {
                             TxtATTime1.setForeground(java.awt.Color.BLACK);
                         }

                         
                         if (!isValid) {
                             JOptionPane.showMessageDialog(this, "Please correct the highlighted fields.", "Error", JOptionPane.ERROR_MESSAGE);
                         } 
                         
                else {
                    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
                        
                        //teacher id eka automatically genarate vena eka
                        String lastTeacherIdQuery = "SELECT Teacher_Id FROM teacher ORDER BY Teacher_Id DESC LIMIT 1";
                        try (PreparedStatement lastTeacherIdStatement = con.prepareStatement(lastTeacherIdQuery)) {
                            ResultSet resultSet = lastTeacherIdStatement.executeQuery();
                            int lastTeacherId = 0; 
                            if (resultSet.next()) {
                                lastTeacherId = Integer.parseInt(resultSet.getString("Teacher_Id"));
                            }

                            int newTeacherId = lastTeacherId + 1;
                            String newTeacherIdString = String.format("%03d", newTeacherId); 
                            
                            

                    

             //  teacher data base ekata data insert kara
                    String TRegSql = "INSERT INTO teacher (Teacher_Id, Teacher_Name, Address,Day,Time, Telephone_Num, Subject, DOR  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement teacherStatement = con.prepareStatement(TRegSql)) {
                         teacherStatement.setString(1, newTeacherIdString);
                         teacherStatement.setString(2, teacherName); 
                         teacherStatement.setString(3, TAddress);
                         teacherStatement.setString(4, date);
                         teacherStatement.setString(5, time);
                         teacherStatement.setString(6,TPhone );
                         teacherStatement.setString(7, subject);
                         teacherStatement.setString(8, TDor);

                         teacherStatement.executeUpdate();


                        JOptionPane.showMessageDialog(this, "Update Successfully!");
                            
                        

                        // Clear input tika
                        TxtTRname.setText(null);
                        TxtTRaddress.setText(null);
                        TxtTRnumber.setText(null);
                        TxtTRID.setText(null);
                        TxtATTime1.setText(null);
                        JATDor.setCalendar(null);

                        if (JTRsubject.getItemCount() > 0) {
                            JTRsubject.setSelectedIndex(0);
                        }
                        if (JATGrade1.getItemCount() > 0) {
                            JATGrade1.setSelectedIndex(0);
                        }
                        if (JATD2.getItemCount() > 0) {
                            JATD2.setSelectedIndex(0);
                        }
                        
                        
                    } 
                    }
                }            catch (SQLException ex) {
                                 Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
                             }
            }
            }
    }//GEN-LAST:event_BtnTRSubmitActionPerformed

    
    
    
    // Teacher registration eke Reset Button eka 
    private void BtnTRResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTRResetActionPerformed
         
        TxtTRname.setText(null);
        TxtTRaddress.setText(null);
        TxtTRnumber.setText(null);
        TxtTRID.setText(null);
        TxtATTime1.setText(null);
        JATDor.setCalendar(null);

        if (JTRsubject.getItemCount() > 0) 
            { JTRsubject.setSelectedIndex(0);}
        
        
        if (JATGrade1.getItemCount() > 0)
            {JATGrade1.setSelectedIndex(0);}
                        
        
        if (JATD2.getItemCount() > 0) 
            {JATD2.setSelectedIndex(0);}
                        
    }//GEN-LAST:event_BtnTRResetActionPerformed

    
    
    
    
    // Student Registration eke database eken JTable ekata data pass kara
    private void BtnSDRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSDRefreshActionPerformed


    
          try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
    String query = "SELECT p.Parent_Name, p.PTelephone_Num, s.Student_Id, s.FUll_Name, s.Address, s.Telephone_num, s.Gender, s.Grade, "
                        + "s.Date_Of_Birth, s.Date_Of_Reg, sub.SubjectName " +
                   "FROM parent p " +
                   "JOIN student s ON p.Parent_Id = s.Parent_Id " +
                   "JOIN student_subject ss ON s.Student_Id = ss.Student_Id " +
                   "JOIN subject sub ON ss.Subject_Id = sub.Subject_Id";

    try (PreparedStatement statement = con.prepareStatement(query)) {
        ResultSet resultSet = statement.executeQuery();

        
        DefaultTableModel model = (DefaultTableModel) JSDTable.getModel();
        model.setRowCount(0);


        while (resultSet.next()) {
            Object[] row = new Object[]{
                resultSet.getString("Student_Id"),
                resultSet.getString("FUll_Name"),
                resultSet.getString("Address"),
                resultSet.getString("Telephone_num"),
                resultSet.getString("Gender"),
                resultSet.getString("Date_Of_Birth"),
                resultSet.getString("Date_Of_Reg"),
                resultSet.getString("Grade"),
                resultSet.getString("SubjectName"),
                resultSet.getString("Parent_Name"),
                resultSet.getString("PTelephone_Num")
            };
            model.addRow(row);
        }

    }
}       catch (SQLException ex) {
            Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BtnSDRefreshActionPerformed

    
    
    
    
    //Subject , Grade call karaddi e details withrak Jtable eke pennanawa
    private void BtnSDSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSDSearchActionPerformed
        
        
            String subject = (String) jComboBox1.getSelectedItem();
            String grade = (String) JSDGrade.getSelectedItem();      

    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
         String query = "SELECT p.Parent_Name, p.PTelephone_Num, s.Student_Id, s.FUll_Name, s.Address, s.Telephone_num, s.Gender, s.Grade, s.Date_Of_Birth, "
                    + "s.Date_Of_Reg, sub.SubjectName " +
                   "FROM parent p " +
                   "JOIN student s ON p.Parent_Id = s.Parent_Id " +
                   "JOIN student_subject ss ON s.Student_Id = ss.Student_Id " +
                   "JOIN subject sub ON ss.Subject_Id = sub.Subject_Id " +
                   "WHERE s.Grade = ? AND sub.SubjectName = ?";

    try (PreparedStatement statement = con.prepareStatement(query)) {
        statement.setString(1, grade);
        statement.setString(2, subject);

        ResultSet resultSet = statement.executeQuery();

        DefaultTableModel model = (DefaultTableModel) JSDTable.getModel();
        model.setRowCount(0);

        while (resultSet.next()) {
            Object[] row = new Object[]{
                resultSet.getString("Student_Id"),
                resultSet.getString("FUll_Name"),
                resultSet.getString("Address"),
                resultSet.getString("Telephone_num"),
                resultSet.getString("Gender"),
                resultSet.getString("Date_Of_Birth"),
                resultSet.getString("Date_Of_Reg"),
                resultSet.getString("Grade"),
                resultSet.getString("SubjectName"),
                resultSet.getString("Parent_Name"),
                resultSet.getString("PTelephone_Num")
            };
            model.addRow(row);
        }

    }
} catch (SQLException ex) {
    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
}
    }//GEN-LAST:event_BtnSDSearchActionPerformed

    
    
    
    
    // Student Registration eke delete kalama databse table eken values delete kara
    private void BtnSDDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSDDeleteActionPerformed
        
       
       
        
                
                

    
    }//GEN-LAST:event_BtnSDDeleteActionPerformed

    
    
    
    private void BtnSDEdit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSDEdit1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnSDEdit1ActionPerformed

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //Teacher_id call karaddi e details withrak Jtable eke pennanawa
    private void BtnTSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTSearchActionPerformed
      
                
                   String teacherId = TxtTDTeacherId.getText();
String squery = "SELECT Teacher_Id, Teacher_Name, Address, Telephone_Num, DOR, Subject, Day, Time FROM teacher";

if (!teacherId.isEmpty()) {
    squery += " WHERE Teacher_Id = ?";
}

try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
    PreparedStatement ps = con.prepareStatement(squery);
    if (!teacherId.isEmpty()) {
        ps.setString(1, teacherId);
    }
    ResultSet rs = ps.executeQuery();

    DefaultTableModel model = (DefaultTableModel) TDetailsTable.getModel();
    model.setRowCount(0);

    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("Teacher_Id"),
            rs.getString("Teacher_Name"),
            rs.getString("Address"),
            rs.getString("Telephone_Num"),
            rs.getString("DOR"),
            rs.getString("Subject"),
            rs.getString("Day"),
            rs.getString("Time")
        });
    }

    rs.close();
    ps.close();

} catch (SQLException ex) {
    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
}
    }//GEN-LAST:event_BtnTSearchActionPerformed

    
    
    // Teacher Details eke raw ekak delete karanawa
    private void BtnTDDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTDDeleteActionPerformed
        
        
                    int selectedRowIndex = TDetailsTable.getSelectedRow();

                        if (selectedRowIndex != -1) { 
                            String Id = (String) TDetailsTable.getValueAt(selectedRowIndex, 0);

                             String deleteTeacherQuery = "DELETE FROM teacher WHERE Teacher_Id = ?";

                try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
                     PreparedStatement deleteTeacherPst = con.prepareStatement(deleteTeacherQuery)) {

                    deleteTeacherPst.setString(1, Id);
                    deleteTeacherPst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Delete That Row Successfully!");

                } catch (SQLException ex) {
                    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
                } 
            }
            
        
    }//GEN-LAST:event_BtnTDDeleteActionPerformed

    
    
    private void BtnTDRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTDRefreshActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnTDRefreshActionPerformed

    
    
    
    // Teacher, Subject database table walin JTable eka values pass kara
    private void BtnTSRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTSRefreshActionPerformed
        
        
        
        
        
                 try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
            Statement st = con.createStatement();

            String squery = "SELECT Teacher_Id, Teacher_Name, Subject, Day, Time FROM teacher ";
            ResultSet rs = st.executeQuery(squery);

            DefaultTableModel model = (DefaultTableModel) JTSTable1.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("Teacher_Id"),
                    rs.getString("Teacher_Name"),
                    rs.getString("Subject"),
                    rs.getString("Day"),
                    rs.getString("Time"),
                    
                });

            }

            rs.close();
            st.close();
            
            
            //search kara eke clear kara
            TxtTDTeacherId.setText(null);
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_BtnTSRefreshActionPerformed

    
    
    
     
    // teacher_id eka call karama eka witharak JTable eke pennanawa
    private void BtnTSSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTSSearchActionPerformed
        
        
        String teacherId = TxtTSTeacherID.getText();
String squery = "SELECT Teacher_Id, Teacher_Name, Subject, Day, Time FROM teacher";

if (!teacherId.isEmpty()) {
    squery += " WHERE Teacher_Id = ?";
}

try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
    PreparedStatement ps = con.prepareStatement(squery);
    if (!teacherId.isEmpty()) {
        ps.setString(1, teacherId);
    }
    ResultSet rs = ps.executeQuery();

    DefaultTableModel model = (DefaultTableModel) JTSTable1.getModel();
    model.setRowCount(0);

    while (rs.next()) {
        model.addRow(new Object[]{
            rs.getString("Teacher_Id"),
            rs.getString("Teacher_Name"),
            rs.getString("Subject"),
            rs.getString("Day"),
            rs.getString("Time"),
            
        });
    }

    rs.close();
    ps.close();

} catch (SQLException ex) {
    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
}
    }//GEN-LAST:event_BtnTSSearchActionPerformed

    
    
    
    //student id eka call karaddi Payment eke textfeild walata valuse pena eka
    private void btnPSTudentIDSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPSTudentIDSearchActionPerformed
        
        
        
           String StudentId = TxtPStID.getText();
           String squery = "SELECT Student_Id, FUll_Name, Grade FROM student WHERE 1=1";

           if (!StudentId.isEmpty()) {
               squery += " AND Student_Id = ?";
           }

           try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
               PreparedStatement ps = con.prepareStatement(squery);
               if (!StudentId.isEmpty()) {
                   ps.setString(1, StudentId);
               }
               ResultSet rs = ps.executeQuery();

               while (rs.next()) {
                   TxtPID.setText(rs.getString("Student_Id"));
                   TxtPName.setText(rs.getString("FUll_Name"));
                   JPGrade.setText(rs.getString("Grade"));
                   
               }

               rs.close();
               ps.close();

           } catch (SQLException ex) {
               Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
           }
        
        
    }//GEN-LAST:event_btnPSTudentIDSearchActionPerformed

    
    
    
    
    //payment database table eke values save kara
    private void btnPSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPSubmitActionPerformed
        
        
            String StudentID = TxtPID.getText();
            String Ammount = TxtPAmount.getText();
            String grade = JPGrade.getText();
            String Subject = (String) JPSubject.getSelectedItem();
            String Status = (String) JPStatus.getSelectedItem();
            int Month = jPWichMonth.getMonth()+ 1;
            
            

            
            // Validation tika
            if (Ammount.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                boolean isValid = true;

                if (Ammount.matches("[a-zA-Z]+")) {
                    isValid = false;
                    TxtPAmount.setForeground(java.awt.Color.RED);
                } else {
                    TxtPAmount.setForeground(java.awt.Color.BLACK);
                }

                if (!isValid) {
                    JOptionPane.showMessageDialog(this, "Please correct the highlighted field.", "Error", JOptionPane.ERROR_MESSAGE);
                } 
                
                    // payment id eka auto genarate kara
                else {
                    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
                        String lastPaymentIdQuery = "SELECT Payment_Id FROM payment ORDER BY Payment_Id DESC LIMIT 1";
                        try (PreparedStatement lastPaymentIdStatement = con.prepareStatement(lastPaymentIdQuery)) {
                            ResultSet resultSet = lastPaymentIdStatement.executeQuery();
                            int lastPaymentId = 0;
                            if (resultSet.next()) {
                                lastPaymentId = resultSet.getInt("Payment_Id");
                            }

                            int newPaymentId = lastPaymentId + 1;
                            String newPaymentIdString = String.format("%03d", newPaymentId);

                            
                            
                            // payment table ekata insert kara
                            String PaymentSql = "INSERT INTO payment (Amount, Month, Payment_Id, Student_Id, Grade, Subject, Status) VALUES (?, ?, ?, ?, ?, ?, ?)";
                            try (PreparedStatement PaymentStatement = con.prepareStatement(PaymentSql)) {
                                PaymentStatement.setString(1, Ammount);
                                PaymentStatement.setInt(2, Month);
                                PaymentStatement.setString(3, newPaymentIdString);
                                PaymentStatement.setString(4, StudentID);
                                PaymentStatement.setString(5, grade);
                                PaymentStatement.setString(6, Subject);
                                PaymentStatement.setString(7, Status);

                                PaymentStatement.executeUpdate();
                            }

                            
                            
                            // subject_id eka subject table eken gaththa
                            String subjectIdQuery = "SELECT Subject_Id FROM subject WHERE Subject_Name = ?";
                            try (PreparedStatement subjectIdStatement = con.prepareStatement(subjectIdQuery)) {
                                subjectIdStatement.setString(1, Subject);
                                ResultSet subjectResultSet = subjectIdStatement.executeQuery();
                                String subjectID = null;
                                if (subjectResultSet.next()) {
                                    subjectID = subjectResultSet.getString("Subject_Id");
                                }

                                
                                // subject_payment table ekata insert kara
                                String SubPaySql = "INSERT INTO subject_payment (Subject_Id, Payment_Id) VALUES (?, ?)";
                                try (PreparedStatement subPayjectStatement = con.prepareStatement(SubPaySql)) {
                                    subPayjectStatement.setString(1, subjectID);
                                    subPayjectStatement.setString(2, newPaymentIdString);

                                    subPayjectStatement.executeUpdate();
                                    
                                }
                            }
                        }
                        
                        
                        
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    JOptionPane.showMessageDialog(this, "Updated Successfully!");
                    TxtPID.setText(null);
                    TxtPAmount.setText(null);
                    JPGrade.setText(null);
                    TxtPName.setText(null);
                    TxtPStID.setText(null);
                    
                    
                }
            }

        
    }//GEN-LAST:event_btnPSubmitActionPerformed

    
    //Payment eke Reset kara
    private void btnPResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPResetActionPerformed
        
                    TxtPID.setText(null);
                    TxtPAmount.setText(null);
                    JPGrade.setText(null);
                    TxtPName.setText(null);
                    TxtPStID.setText(null);
    }//GEN-LAST:event_btnPResetActionPerformed

    
    
    
    // Payment view eke Refresh klama database eke values tika jTable eka show wenawa
    private void btnVPRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVPRefreshActionPerformed
        
        
                    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    Statement st = con.createStatement();

                    String squery = "SELECT p.Student_Id, p.Payment_Id, p.Subject, p.Grade, p.Month, p.Amount, p.Status, "
                                    + "s.Full_Name "  
                                    + "FROM payment p " +
                                    "INNER JOIN student s ON p.Student_Id = s.Student_Id"; 

                    ResultSet rs = st.executeQuery(squery);

                    DefaultTableModel model = (DefaultTableModel) JVPTable.getModel();
                    model.setRowCount(0);

                    while (rs.next()) {
                        model.addRow(new Object[]{
                            rs.getString("Student_Id"),
                            rs.getString("Full_Name"), 
                            rs.getString("Grade"),
                            rs.getString("Subject"),
                            rs.getString("Amount"),
                            rs.getString("Status"),
                            rs.getString("Month")
                        });
                    }

                    rs.close();
                    st.close();

                } catch (SQLException ex) {
                    Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
                }
        
    }//GEN-LAST:event_btnVPRefreshActionPerformed

    
    
    private void jPVPSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPVPSearchActionPerformed
        
            /* String studentId = TxtSDStudentID.getText();
             String selectedGrade = (String) JSDGrade.getSelectedItem();
             int selectedMonth = JPVPMCalander.getMonth() + 1; 
             String selectedSubject = (String) JPVPSubject1.getSelectedItem();

             String squery = "SELECT p.Student_Id, p.Subject, p.Grade, p.Month, p.Amount, p.Status, " +
                             "s.Full_Name " +
                             "FROM payment p " +
                             "INNER JOIN student s ON p.Student_Id = s.Student_Id ";
                             

             
             try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
                  PreparedStatement ps = con.prepareStatement(squery)) {

                 
                 int paramIndex = 1;
                 if (!studentId.isEmpty()) {
                     ps.setString(paramIndex++, studentId);
                 } else {
                     ps.setNull(paramIndex++, Types.VARCHAR);
                 }

                 if (selectedMonth != 0) {
                     ps.setInt(paramIndex++, selectedMonth);
                 } else {
                     ps.setNull(paramIndex++, Types.INTEGER);
                 }

                 if (!selectedGrade.isEmpty()) {
                     ps.setString(paramIndex++, selectedGrade);
                 } else {
                     ps.setNull(paramIndex++, Types.VARCHAR);
                 }

                 if (!selectedSubject.equals("All")) {
                     ps.setString(paramIndex++, selectedSubject);
                 } else {
                     ps.setNull(paramIndex++, Types.VARCHAR);
                 }

                 
                 try (ResultSet rs = ps.executeQuery()) {
                     DefaultTableModel model = (DefaultTableModel) JSDTable.getModel();
                     model.setRowCount(0);

                     while (rs.next()) {
                         model.addRow(new Object[]{
                             rs.getString("Student_Id"),
                             rs.getString("Full_Name"),
                             rs.getString("Grade"),
                             rs.getString("Subject"),
                             rs.getString("Amount"),
                             rs.getString("Status"),
                             rs.getString("Month")
                         });
                     }
                 }

             } catch (SQLException ex) {
                 Logger.getLogger(Dash_Board.class.getName()).log(Level.SEVERE, null, ex);
             }*/
    }//GEN-LAST:event_jPVPSearchActionPerformed

    private void JSDGradeComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_JSDGradeComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_JSDGradeComponentHidden

    private void BtnTDExit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTDExit1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnTDExit1ActionPerformed

    
    
 
    
    
    
    
    
   
   
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dash_Board.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dash_Board.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dash_Board.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dash_Board.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dash_Board().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAReset;
    private javax.swing.JButton BtnASubmit;
    private javax.swing.JButton BtnAlldetails;
    private javax.swing.JButton BtnAttendence;
    private javax.swing.JButton BtnLogOut;
    private javax.swing.JButton BtnPayment;
    private javax.swing.JButton BtnRReset;
    private javax.swing.JButton BtnRSubmit;
    private javax.swing.JButton BtnRejistration;
    private javax.swing.JButton BtnReport;
    private javax.swing.JButton BtnSDDelete;
    private javax.swing.JButton BtnSDEdit1;
    private javax.swing.JButton BtnSDRefresh;
    private javax.swing.JButton BtnSDSearch;
    private javax.swing.JButton BtnTDDelete;
    private javax.swing.JButton BtnTDExit1;
    private javax.swing.JButton BtnTDRefresh;
    private javax.swing.JButton BtnTRReset;
    private javax.swing.JButton BtnTRSubmit;
    private javax.swing.JButton BtnTSRefresh;
    private javax.swing.JButton BtnTSSearch;
    private javax.swing.JButton BtnTSearch;
    private javax.swing.JButton BtnTimeShedule;
    private javax.swing.JButton Btnalldetails;
    private javax.swing.JButton Btnregistration;
    private javax.swing.JComboBox<String> JAGrade;
    private javax.swing.JComboBox<String> JASubject;
    private javax.swing.JComboBox<String> JATD2;
    private javax.swing.JComboBox<String> JATGrade1;
    private javax.swing.JTable JATable;
    private javax.swing.JTextField JPGrade;
    private javax.swing.JComboBox<String> JPStatus;
    private javax.swing.JComboBox<String> JPSubject;
    private javax.swing.JComboBox<String> JPVPSubject1;
    private javax.swing.JComboBox<String> JRComboBoxGrade;
    private javax.swing.JComboBox<String> JSDGrade;
    private javax.swing.JTable JSDTable;
    private javax.swing.JComboBox<String> JTRsubject;
    private javax.swing.JTable JTSTable1;
    private javax.swing.JComboBox<String> JVAGrade;
    private javax.swing.JComboBox<String> JVASubject;
    private javax.swing.JTable JVATable;
    private javax.swing.JComboBox<String> JVPGrade1;
    private javax.swing.JTable JVPTable;
    private javax.swing.JLabel LblAddress;
    private javax.swing.JLabel LblBirth;
    private javax.swing.JLabel LblGender;
    private javax.swing.JLabel LblName;
    private javax.swing.JLabel LblNumber;
    private javax.swing.JLabel LblOlympus2;
    private javax.swing.JLabel LblOlympus3;
    private javax.swing.JLabel LblPname;
    private javax.swing.JLabel LblRejistation;
    private javax.swing.JLabel LblStID;
    private javax.swing.JLabel LblStID4;
    private javax.swing.JLabel LblStID5;
    private javax.swing.JLabel LblSubject;
    private javax.swing.JLabel LblSubject3;
    private javax.swing.JLabel LblTAddress;
    private javax.swing.JLabel LblTID;
    private javax.swing.JLabel LblTID1;
    private javax.swing.JLabel LblTName;
    private javax.swing.JLabel LblTNumber;
    private javax.swing.JLabel LblTSubject;
    private javax.swing.JLabel Lblnumber;
    private javax.swing.JComboBox<String> SRSbject;
    private javax.swing.JTable TDetailsTable;
    private javax.swing.JTextField TxtATTime1;
    private javax.swing.JTextField TxtPAmount;
    private javax.swing.JTextField TxtPID;
    private javax.swing.JTextField TxtPName;
    private javax.swing.JTextField TxtPStID;
    private javax.swing.JTextField TxtRAddress;
    private javax.swing.JTextField TxtRName;
    private javax.swing.JTextField TxtRNumber;
    private javax.swing.JTextField TxtRPname;
    private javax.swing.JTextField TxtRPnumber;
    private javax.swing.JTextField TxtRStID;
    private javax.swing.JTextField TxtSDStudentID;
    private javax.swing.JTextField TxtTDTeacherId;
    private javax.swing.JTextField TxtTRID;
    private javax.swing.JTextField TxtTRaddress;
    private javax.swing.JTextField TxtTRname;
    private javax.swing.JTextField TxtTRnumber;
    private javax.swing.JTextField TxtTSTeacherID;
    private javax.swing.JButton btnPReset;
    private javax.swing.JButton btnPSTudentIDSearch;
    private javax.swing.JButton btnPSubmit;
    private javax.swing.JButton btnVPRefresh;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel jAttendence;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBoxGender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelPic;
    private javax.swing.JButton jPVPSearch;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelRegistation;
    private javax.swing.JPanel jPanelStudentDetails;
    private javax.swing.JPanel jPayment;
    private javax.swing.JPanel jReport;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JPanel jShedule;
    private javax.swing.JPanel jTDetails;
    private javax.swing.JPanel jTRegistration;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    private static class main {


        public main() {
        }
    }


    
}
