/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package StudentRejistration;


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;

/**
 *
 * @author Shaminda
 */
public class Login extends javax.swing.JFrame {

 
    public Login() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LblOlympus = new javax.swing.JLabel();
        LblOlympus1 = new javax.swing.JLabel();
        LblName = new javax.swing.JLabel();
        LblPassword = new javax.swing.JLabel();
        TxtName = new javax.swing.JTextField();
        JPassword = new javax.swing.JPasswordField();
        JShow = new javax.swing.JCheckBox();
        BtnExit = new javax.swing.JButton();
        BtnLogin = new javax.swing.JButton();
        BtnReset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(247, 241, 236));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsListener() {
            public void ancestorMoved(java.awt.event.HierarchyEvent evt) {
            }
            public void ancestorResized(java.awt.event.HierarchyEvent evt) {
                jPanel1AncestorResized(evt);
            }
        });
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(243, 227, 215));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 153), new java.awt.Color(204, 255, 204), new java.awt.Color(255, 239, 202), new java.awt.Color(255, 232, 209)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LblOlympus.setFont(new java.awt.Font("Bookman Old Style", 1, 28)); // NOI18N
        LblOlympus.setText("OLYMPUS");
        jPanel2.add(LblOlympus, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 190, -1));

        LblOlympus1.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        LblOlympus1.setText("Institue Of Education");
        jPanel2.add(LblOlympus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 281, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 80));

        LblName.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        LblName.setText("User Name:");
        jPanel1.add(LblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 110, 90, -1));

        LblPassword.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        LblPassword.setText("Password:");
        jPanel1.add(LblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 90, -1));

        TxtName.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(TxtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 190, -1));

        JPassword.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(JPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, 190, -1));

        JShow.setText("Show Password");
        JShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JShowActionPerformed(evt);
            }
        });
        jPanel1.add(JShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, -1, -1));

        BtnExit.setBackground(new java.awt.Color(243, 227, 215));
        BtnExit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BtnExit.setText("Exit");
        BtnExit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnExit.setMaximumSize(new java.awt.Dimension(42, 24));
        BtnExit.setMinimumSize(new java.awt.Dimension(42, 24));
        BtnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnExitActionPerformed(evt);
            }
        });
        jPanel1.add(BtnExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, 90, 30));

        BtnLogin.setBackground(new java.awt.Color(243, 227, 215));
        BtnLogin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BtnLogin.setText("Login");
        BtnLogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLoginActionPerformed(evt);
            }
        });
        jPanel1.add(BtnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 90, 30));

        BtnReset.setBackground(new java.awt.Color(243, 227, 215));
        BtnReset.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BtnReset.setText("Reset");
        BtnReset.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BtnReset.setPreferredSize(new java.awt.Dimension(60, 24));
        BtnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnResetActionPerformed(evt);
            }
        });
        jPanel1.add(BtnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 270, 90, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel1AncestorResized(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jPanel1AncestorResized
        setLocationRelativeTo(null);
    }//GEN-LAST:event_jPanel1AncestorResized

    private void BtnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnResetActionPerformed
        TxtName.setText(null);
        JPassword.setText(null);
    }//GEN-LAST:event_BtnResetActionPerformed

    @SuppressWarnings("CallToPrintStackTrace")
    private void BtnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLoginActionPerformed

        var use = TxtName.getText();
        var pass = new String(JPassword.getPassword());

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/management_system", "root", "shaminda2002#");

            String query = "SELECT * FROM login WHERE user_name = ? AND password = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, use);
            pstmt.setString(2, pass);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Dash_Board home = new Dash_Board();
                home.setVisible(true);
                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password!");
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_BtnLoginActionPerformed

    
    
    
    
    
    private void BtnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_BtnExitActionPerformed

    private void JShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JShowActionPerformed
        if(JShow.isSelected()){
            JPassword.setEchoChar((char)0);
        }
        else{
            JPassword.setEchoChar('*');
        }
    }//GEN-LAST:event_JShowActionPerformed
  
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnExit;
    private javax.swing.JButton BtnLogin;
    private javax.swing.JButton BtnReset;
    private javax.swing.JPasswordField JPassword;
    private javax.swing.JCheckBox JShow;
    private javax.swing.JLabel LblName;
    private javax.swing.JLabel LblOlympus;
    private javax.swing.JLabel LblOlympus1;
    private javax.swing.JLabel LblPassword;
    private javax.swing.JTextField TxtName;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
